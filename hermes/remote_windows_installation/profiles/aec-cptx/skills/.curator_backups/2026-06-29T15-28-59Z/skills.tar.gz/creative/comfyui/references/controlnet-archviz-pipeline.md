# ControlNet for Architectural Visualization — Normal Map Pipeline

## Problem

When using SDXL img2img on 3D renders of architecture, the model either:
- Barely changes the image (low denoise) → still looks CG
- Invents a completely different building (high denoise) → doesn't match the designed form

Users who designed a specific building care about form fidelity above all else.
"They all look wrong" = the AI is hallucinating generic buildings.

## Solution: Normal Map + ControlNet Depth (txt2img)

Render a **surface normal map** from the 3D scene and use it as the ControlNet
conditioning image for a **txt2img** (NOT img2img) generation.

### Why Normal Maps Beat Depth Maps for Architecture

At aerial camera distances (>300m), depth maps have almost no contrast because:
- Building height (20-50m) vs camera distance (600m) = <10% depth variation
- Ground, building, and nearby structures all compress into the same depth value
- Only mountains/sky show meaningful depth separation

Normal maps encode **surface orientation** (which way each face points), so they
reveal:
- Roof curvature and structural ribs
- Wall vs floor vs ceiling transitions
- Aircraft silhouettes (tiny but present)
- Mountain ridge detail
- All architectural detail invisible in depth

### Rendering the Normal Map from Blender

```python
# In Blender Python
scene.view_layers["ViewLayer"].use_pass_normal = True
# Compositor: RenderLayers.Normal → Viewer Node
# Save via: bpy.data.images["Viewer Node"].save_render(path)
```

Resolution: Match SDXL input (1024x576 for 16:9 aerial).
Samples: 1 is fine — normals don't need path tracing.

### Also Render a Depth Map (useful for combined approaches)

Use inverse depth (1/d) for better near-range contrast:
```python
# After getting raw depth values from Viewer Node:
inv = 1.0 / depth_value
normalized = (inv - min_inv) / (max_inv - min_inv)  # 0-1 range
```

### ComfyUI Workflow (API format)

```
LoadImage(normal_map) → ControlNetApplyAdvanced → KSampler → VAEDecode → SaveImage
                              ↑
CheckpointLoader(SDXL) → CLIPTextEncode(prompt)
                       → CLIPTextEncode(neg)
ControlNetLoader(depth-sdxl) ↗
EmptyLatentImage(1024x576) → KSampler.latent_image
```

Key: Use **EmptyLatentImage** (txt2img), NOT VAEEncode of the render (img2img).
The ControlNet provides ALL the structural guidance; img2img just fights it.

### Optimal Parameters

| Parameter | Value | Notes |
|-----------|-------|-------|
| ControlNet strength | 0.75-0.80 | Sweet spot. 0.90 = illustration look. 0.65 = form drift |
| ControlNet end_percent | 0.9 | Let final steps refine freely |
| CFG | 7.0-8.0 | Standard SDXL range |
| Steps | 35 | Good quality/speed balance |
| Sampler | dpmpp_2m + karras | Reliable for architecture |
| Denoise | 1.0 | Full txt2img — NOT img2img denoise |

### Prompt Strategy for Architecture

Include in positive prompt:
- Building material description (solar panels, glass, steel, concrete)
- Specific aircraft types (Boeing 737, Airbus A320) for scale
- Geographic context (Rocky Mountains, Colorado, prairie)
- Camera/lens spec (Canon EOS R5, 24mm, f/8) for photographic look
- "aerial photograph" not "aerial render"

Include in negative prompt:
- "CG render, 3D render" to push away from synthetic look
- Wrong building shapes: "four arms, X-shape" if Y-shape is intended
- "night, dark, underexposed" if golden hour is wanted

### Results Observed

| Approach | Photorealism | Form Fidelity | Best Score |
|----------|-------------|---------------|------------|
| Pure img2img (d=0.80) | 8/10 | 3/10 | 8/10 but wrong building |
| ControlNet depth (RGB as input) | 5/10 | 5/10 | Inconsistent |
| ControlNet depth (real depth map) | 5/10 | 6/10 | Depth too flat |
| ControlNet depth (inverse depth) | 5/10 | 6.5/10 | Better but still flat |
| **ControlNet depth (normal map)** | **8/10** | **8.5/10** | **Best overall** |
| Hybrid (CN + img2img) | 3.5/10 | 7/10 | Double conditioning fails |

### Seed Sensitivity

Results vary significantly by seed. Always run 6-10 seeds at the optimal
strength and pick the best. File size correlates loosely with detail (larger
PNG = more visual information = usually better).

### Blender 5.1 API Notes

- Compositor node tree: `scene.compositing_node_group` (not `scene.node_tree`)
- Must create: `bpy.data.node_groups.new("name", "CompositorNodeTree")`
- `CompositorNodeComposite` → removed, use `CompositorNodeViewer` or `CompositorNodeOutputFile`
- `CompositorNodeMixRGB` → removed, use `CompositorNodeAlphaOver`
- `CompositorNodeMapRange` → removed, normalize in Python instead
- `CompositorNodeGlare` → settings via input sockets, not properties
  - `.glare_type` → input "Type" = 'Fog Glow' (display name, not enum)
  - `.quality` → input "Quality" = 'High'
- `CompositorNodeColorBalance` → settings via input sockets
  - `.correction_method` → input "Type" = 'Lift/Gamma/Gain'
  - Lift/Gamma/Gain are RGBA input sockets (find by name + type == "RGBA")
- `CompositorNodeOutputFile` → no `base_path` attribute
- Sky texture: no 'NISHITA' type, options are 'PREETHAM', 'HOSEK_WILKIE', 'SINGLE_SCATTERING', 'MULTIPLE_SCATTERING'
- GPU: `prefs.compute_device_type = 'CUDA'`, then `prefs.get_devices()`, then enable NVIDIA devices
- Color management: AgX available as view_transform, look names use display names not enum
