# Blender Export & Scene Setup — From Rhino Detailing

Procedure for transferring Rhino geometry to Blender and setting up Cycles rendering.

## Rhino Export Pitfall: _-Export blocks the MCP slot

**NEVER** use `mcp_rhino_run_command` with `_-Export` to export OBJ/FBX. The Export command opens a file dialog that blocks the entire MCP slot. Once blocked, `run_python`, `run_csharp`, and `run_command` all fail with "Rhino is already running a command." The only recovery is closing Rhino manually — `close_slot` cannot kill an adopted (user-started) Rhino.

### Workaround: Recreate geometry in Blender programmatically

Since all building dimensions are known from the Rhino massing phase, recreate geometry directly in Blender via `mcp_blender_execute_blender_code`. This is actually cleaner because:
- Materials can be assigned inline during creation
- Collections can be organized during creation
- No coordinate-system conversion headaches (both use Z-up when working directly)
- Custom properties (`obj["material"]`) are set immediately

### Alternative: Write OBJ manually from Rhino Python (proven June 15 2026, 381 objects)

Export from Rhino by writing the OBJ file directly from `run_python`. This preserves material group assignments and avoids the blocking Export dialog.

**Key pattern:**
```python
import Rhino.Geometry as rg
import Rhino.DocObjects as rd

mp = rg.MeshingParameters.Default
mp.MinimumEdgeLength = 1.0
mp.MaximumEdgeLength = 500.0

# Group objects by material tag
objects_by_mat = {}
for obj in doc.Objects.GetObjectList(es):
    mat_tag = obj.Attributes.GetUserString("material") or "M_Concrete_WarmBone"
    meshes = []
    geo = obj.Geometry
    if geo.GetType().Name == "Brep":
        ms = rg.Mesh.CreateFromBrep(geo, mp)
        if ms:
            meshes.extend(ms)
    # Convert verts: mm -> meters (divide by 1000)
    for mesh in meshes:
        for i in range(mesh.Vertices.Count):
            v = mesh.Vertices[i]
            verts.append((v.X / 1000.0, v.Y / 1000.0, v.Z / 1000.0))
    # Write OBJ with usemtl groups and 1-indexed face indices

# Write companion .mtl with placeholder Kd values
```

**Results (June 15 2026, cliff_house):** 381 objects → 12MB OBJ, 202K vertices, 196K faces, 2276 mesh groups, 8 material groups. Coordinates written in meters. No coordinate swap needed — Blender OBJ import handles axis mapping via `forward_axis`/`up_axis` params.

**Large-scene mesh density pitfall (June 15 2026, airport — 922 exportable objects):** Default `MeshingParameters` on airport-scale models (1,570 Rhino objects, 3km site) produced a 529MB OBJ with 4.5M vertices — far too heavy for Blender. Re-export with coarser settings halved it:
```python
mp = rg.MeshingParameters.Default
mp.MinimumEdgeLength = 500    # 500mm min (was 100mm)
mp.MaximumEdgeLength = 20000  # 20m max (was 5m)
mp.SimplePlanes = True        # merge coplanar faces
```
Result: 217MB, 1.9M vertices — still large but workable in Blender 5.1. For scenes over ~500 objects or 1km site extent, always use coarse mesh params. The terrain mesh alone was 1.6M vertices at these settings. **Rule of thumb:** MinimumEdgeLength ≥ 0.5m and MaximumEdgeLength ≥ 10m for campus/airport scale.

**Important:** Do NOT apply Y/Z coordinate swap in the OBJ writer. Write raw Rhino coordinates (divided by 1000 for meters) and use `bpy.ops.wm.obj_import(forward_axis='Y', up_axis='Z')` for identity mapping. Both Rhino and Blender use X=right, Y=forward, Z=up.

## Material Tagging in Rhino (Step 1)

Before export/transfer, tag all Rhino objects with material User Text. Use a **list of tuples** (not dict) for priority ordering — first match wins.

```python
# Layer keyword -> material tag. Order matters: most specific first.
layer_material_map = [
    ("terrain",         "M_Terrain_DesertCoastal"),
    ("glazing",         "M_Glass_TintedBronze"),
    ("mullions",        "M_Aluminum_Bronze"),
    ("railings",        "M_Steel_EdgeTrim"),
    ("entry",           "M_Wood_DarkCedar"),
    ("garage_doors",    "M_Steel_EdgeTrim"),
    ("pool_coping",     "M_Aluminum_Bronze"),      # bronze coping
    ("pool",            "M_Concrete_Pool"),
    ("firepit",         "M_Stone_Fieldstone"),
    ("patio",           "M_Stone_Fieldstone"),      # stone deck slabs
    ("retaining",       "M_Stone_Fieldstone"),
    ("driveway",        "M_Terrain_DesertCoastal"), # decomposed granite
    ("building_pad",    "M_Concrete_WarmBone"),
    ("garage_pad",      "M_Concrete_WarmBone"),
    ("patio_pad",       "M_Concrete_WarmBone"),
    ("floor_slabs",     "M_Concrete_WarmBone"),
    ("partition_walls", "M_Concrete_WarmBone"),
    ("service_core",    "M_Concrete_WarmBone"),
    ("stairs",          "M_Concrete_WarmBone"),
    ("L1_solids",       "M_Concrete_WarmBone"),
    ("L2_solids",       "M_Concrete_WarmBone"),
    ("L2_balcony",      "M_Concrete_WarmBone"),
    ("L2_roof",         "M_Concrete_WarmBone"),
    ("L3_solids",       "M_Concrete_WarmBone"),
    ("L3_balcony",      "M_Concrete_WarmBone"),
    ("L3_roof",         "M_Concrete_WarmBone"),
]

# Also match by object name for edge cases (sidelights, jambs, etc.)
name_material_map = [
    ("glass",     "M_Glass_TintedBronze"),
    ("sidelight", "M_Glass_TintedBronze"),
    ("mull",      "M_Aluminum_Bronze"),
    ("frame",     "M_Aluminum_Bronze"),
    ("jamb",      "M_Aluminum_Bronze"),
    ("head",      "M_Aluminum_Bronze"),
    ("sill",      "M_Aluminum_Bronze"),
    ("transom",   "M_Aluminum_Bronze"),
    ("toprail",   "M_Steel_EdgeTrim"),
    ("post",      "M_Steel_EdgeTrim"),
    ("terrain",   "M_Terrain_DesertCoastal"),
    ("pool",      "M_Concrete_Pool"),
    ("water",     "M_Concrete_Pool"),
    ("entry_door","M_Wood_DarkCedar"),
    ("coping",    "M_Aluminum_Bronze"),
    ("firepit",   "M_Stone_Fieldstone"),
    ("patio",     "M_Stone_Fieldstone"),
]

# Priority: layer keyword → object name keyword → M_Concrete_WarmBone default
obj.Attributes.SetUserString("material", mat_tag)
obj.Attributes.SetUserString("layer", layer.FullPath)
obj.CommitChanges()
```

**Proven results (June 15 2026, 381 objects):**
- M_Aluminum_Bronze: 110 (mullions, frames, coping)
- M_Glass_TintedBronze: 130 (all glazing)
- M_Concrete_WarmBone: 72 (massing, slabs, walls, pads, stairs)
- M_Steel_EdgeTrim: 52 (railings, posts, garage doors)
- M_Concrete_Pool: 6, M_Stone_Fieldstone: 8, M_Terrain_DesertCoastal: 2, M_Wood_DarkCedar: 1

## BlenderMCP TCP Protocol (discovered June 2026)

BlenderMCP (Blender 5.1) listens on TCP port 9876. The protocol is:
- **Format**: JSON with `type` and `params` fields, newline-delimited (`\n` terminated)
- **Execute code**: `{"type": "execute_code", "params": {"code": "<python_code>"}}`
- **Response**: JSON with `status` ("success"/"error") and `result` dict containing `executed` (bool) and `result` (string)
- The `result` field in the response contains whatever is in the `result` variable at the end of the executed script

### Reusable helper script (C:\Users\test\Documents\blender_helper.py)

```python
import socket, json, sys

def blender_exec(code, timeout=30):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(('127.0.0.1', 9876))
    msg = json.dumps({'type': 'execute_code', 'params': {'code': code}})
    s.sendall((msg + '\n').encode())
    data = b''
    try:
        while True:
            chunk = s.recv(65536)
            if not chunk: break
            data += chunk
            # CRITICAL: break as soon as we have complete JSON
            try:
                json.loads(data.decode())
                break
            except:
                continue
    except socket.timeout:
        pass
    s.close()
    if data:
        return json.loads(data.decode())
    return {'status': 'error', 'message': 'no response'}
```

**Socket recv pitfall (June 2026):** Without the JSON-completeness check in the recv loop, the socket hangs indefinitely after receiving the response — the server doesn't close the connection, so `recv` blocks waiting for more data. The `try: json.loads(data); break` pattern is mandatory.

Usage from terminal: `python C:\Users\test\Documents\blender_helper.py <code_file.py>` or `python C:\Users\test\Documents\blender_helper.py --info` for scene info.

The helper supports two modes:
- `blender_helper.py <script.py>` — execute a Python file via BlenderMCP (timeout=120s)
- `blender_helper.py --info` — send `get_scene_info` and print JSON response (object_count, materials_count, object list)

### `result` variable capture is unreliable

Setting `result = "some value"` at the end of execute_code scripts often returns an empty string in the response. This appears to be a BlenderMCP addon issue — the variable is set but not reliably captured by the JSON response serializer.

**Workaround:** Don't rely on `result` for verification. Instead:
- Use `get_scene_info` command to check object/material counts: `{"type": "get_scene_info"}`
- For detailed checks, write to a temp file from bpy and read it back from the terminal
- The `status: success` field is reliable — if it says success, the code executed

### Critical Pitfall: read_factory_settings kills MCP

**NEVER** call `bpy.ops.wm.read_factory_settings()` via MCP — it unregisters all addons including BlenderMCP, killing the TCP server. The socket connection dies and cannot be restored without restarting Blender entirely.

**Instead**, to clear a scene while preserving MCP:
```python
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
for c in list(bpy.data.collections):
    bpy.data.collections.remove(c)
```

### Recovery if MCP dies
```bash
taskkill /IM blender.exe /F
sleep 3
powershell.exe -Command "Start-Process 'C:\Program Files\Blender Foundation\Blender 5.1\blender.exe'"
sleep 10
# Verify: netstat -an | grep "9876.*LISTEN"
```

**Dual-process pitfall (June 2026):** If you relaunch Blender without killing the old process first, both bind port 9876, creating stale connections that hang new requests. Always `taskkill /IM blender.exe /F` before relaunch. After launch, verify only one blender.exe is in the process list and the port shows LISTENING with no leftover ESTABLISHED connections from the old session.

The `schtasks /Run /TN "LaunchBlenderForHermes"` path also works but `powershell.exe Start-Process` is more reliable from MSYS/git-bash.

## Blender Scene Build Strategy (proven end-to-end June 2026, 301 objects + render)

**Three proven approaches, choose by complexity:**

**Approach 1: Recreate from known dimensions (fastest for <50 objects)**
Build geometry directly in Blender via bmesh/bpy.ops using meter-scale coordinates from the geometry reference. Best when massing is simple and detailing is minimal. Proven June 2026 session 2 (24 objects).

**Approach 2: OBJ manual export + import (proven June 15 2026, 381 objects)**
Write OBJ from Rhino Python (see "Write OBJ manually" above), import into Blender. Preserves exact geometry from Rhino including all detailing. Requires post-import cleanup (duplicate materials, separate by material, rotation_mode fix). Best for complex scenes with hundreds of detailed objects.

**Approach 3: Parametric batch generation (proven June 2026 session 1, 301 objects)**
Recreate geometry parametrically in Blender, generating glazing/mullion grids from dimensions. Most control over materials and collections but takes many script steps.

Building a full 300+ object scene via BlenderMCP requires batching into multiple execute_code calls. Each call runs one logical step. This exact sequence was executed successfully on 2026-06-11:

1. **Clear scene + configure Cycles** — select all, delete, remove collections, set engine/samples/resolution
2. **Create materials** — all 8 Cycles materials in one call
3. **Create collections** — flat collection list (Blender links them to scene root)
4. **Site geometry** — terrain ground plane, pad, curtain wall, driveway (4 boxes)
5. **Massing geometry** — all 11 massing volumes (one call)
6. **Curtain wall glazing + mullions** — parametric generation (one large call per face type, ~120s timeout)
7. **Punched windows** — secondary face windows (one call)
8. **Railings + doors** — balcony railings, entry door, garage doors (one call)
9. **Lighting + camera** — sun, sky world, fill light, hero camera (one call)
10. **Save** — `bpy.ops.wm.save_as_mainfile(filepath=...)`
11. **Render** — `bpy.ops.render.render(write_still=True)` with 128 samples, 75% resolution

**Write scripts to disk, execute via helper.** For complex steps, write the Python code to `C:\Users\test\Documents\bstep_N.py` and run via `python blender_helper.py bstep_N.py`. This avoids quoting hell and makes debugging easier.

**File-based script pattern (proven June 2026):** When NOT using the reusable helper, write a self-contained Python file with `write_file` (to e.g. `C:\Users\test\Documents\blender_render.py`) then run via `terminal: python C:/Users/test/Documents/blender_render.py`. This avoids:
- Backslash escaping hell with inline `-c` strings (especially Windows paths with `\U` triggering unicode escape errors)
- The `exit 124` timeout from the Python process wrapper even when Blender commands succeed
- Quote nesting issues when embedding multi-line bpy code in Python `-c` strings

**Terminal timeout for renders:** Always set `timeout=300` or higher on `terminal()` calls that wrap Blender renders. The render blocks synchronously — even GPU renders at 128 samples take 30-60s. A 60s terminal timeout will show `exit 124` even though the render completes and saves the file.

**Verify via get_scene_info between steps.** Don't rely on `result` variable — use `{"type": "get_scene_info"}` which reliably returns object_count and materials_count.

**All coordinates in meters.** Blender works natively in meters. The Rhino model is in mm. When recreating geometry in Blender, divide all Rhino coordinates by 1000 (or use the meter values from DEMO_RULES / geometry reference directly).

**CRITICAL: OBJ import axis mapping.** When writing OBJ from Rhino Python with raw `v x y z` coordinates (Rhino: X=right, Y=forward, Z=up), use `bpy.ops.wm.obj_import(forward_axis='Y', up_axis='Z')` for identity mapping. Do NOT use the Blender default `forward_axis='NEGATIVE_Z', up_axis='Y'` — that's for 3ds Max convention and will swap Y/Z axes, making the building lie on its side. Always verify scene bounding box immediately after import.

## OBJ Import Pitfalls (discovered June 15 2026)

### Duplicate `.001` materials when PBR materials pre-exist

If you create PBR materials first (recommended for cliff_house workflow) and then import an OBJ with a `.mtl` that has the same material names, Blender creates duplicate materials with `.001` suffix. The imported mesh gets the `.001` versions, not your PBR materials.

**Alternative workflow (proven June 15 2026, airport — avoids the problem entirely):**
Import OBJ first, then overwrite the placeholder materials from the .mtl in-place:
1. Import OBJ → Blender creates materials from .mtl with correct names (no .001)
2. Separate by material (`mesh.separate(type='MATERIAL')`)
3. Rename objects by their material name
4. Overwrite each material's node tree with PBR nodes (clear nodes, add Principled BSDF + output, set values)
This avoids the .001 duplication entirely because you're modifying existing materials, not creating competing ones.

**Fix if you already have duplicates — replace and clean up after import:**
```python
obj = bpy.data.objects.get("cliff_house_02_export")
for slot in obj.material_slots:
    if slot.material and slot.material.name.endswith(".001"):
        base_name = slot.material.name[:-4]
        pbr_mat = bpy.data.materials.get(base_name)
        if pbr_mat:
            slot.material = pbr_mat
# Remove orphan .001 materials
for mat in list(bpy.data.materials):
    if mat.name.endswith(".001") and mat.users == 0:
        bpy.data.materials.remove(mat)
```

### Single merged mesh — must separate by material

`bpy.ops.wm.obj_import()` imports the entire OBJ as one mesh object, even with `usemtl` groups. To get per-material objects for collection organization:

```python
obj.select_set(True)
bpy.context.view_layer.objects.active = obj
bpy.ops.mesh.separate(type='MATERIAL')
```

This creates one object per material slot. Each object inherits the material from its faces. Then organize into collections by reading `obj.material_slots[0].material.name`.

### OBJ import axis settings — CRITICAL

For OBJ files written with raw Rhino coordinates (no Y/Z swap in the writer), import with **identity mapping**:
```python
bpy.ops.wm.obj_import(
    filepath=obj_path,
    forward_axis='Y',
    up_axis='Z'
)
```

**Do NOT use `forward_axis='NEGATIVE_Z', up_axis='Y'`** — that's the 3ds Max convention and will swap Y/Z axes, making the building lie on its side. Symptom: the scene's Z range equals the Rhino Y range (north-south span) instead of the Rhino Z range (vertical). Discovered June 15 2026 — the first import attempt produced a scene with Z: -20 to 16.5 (should have been Y range), while Y: -5 to 13.4 (should have been Z range).

### Post-import checklist

1. Replace `.001` materials with PBR versions
2. Separate by material (`mesh.separate(type='MATERIAL')`)
3. Set `rotation_mode = 'XYZ'` on ALL mesh objects (critical — Rhino imports arrive as QUATERNION)
4. Set custom properties: `obj["material"] = mat_name` for downstream pipeline use
5. Organize into collections by material name mapping

## Blender Scene Setup

### Collection hierarchy

**Full hierarchy (for detailed 300+ object scenes):**
```
Scene Collection
├── building_site/
│   ├── terrain/
│   ├── pad/
│   └── curtain_wall/
├── massing/
│   ├── L1_solids/
│   ├── L2_solids/
│   ├── L2_balconies/
│   └── L3_pool/
└── detailing/
    ├── glazing/
    ├── mullions/
    ├── railings/
    ├── entry/
    └── garage/
```

**Rapid-build flat hierarchy (proven June 2026 session 2, 24 objects):**
```
Scene Collection
├── Site/       (terrain, pads, retaining walls, driveway)
├── Building/   (L1/L2 walls, slabs, roof, garage)
├── Glazing/    (glass curtain wall panels)
└── Details/    (entry door, garage doors, railings)
```
Use the flat structure when building quickly from known dimensions. Each collection gets objects with materials assigned inline. Faster to create and easier to manage for scenes under ~50 objects.

### Reusable create_box helpers

**Approach A: bpy.ops (for small batches, straightforward)**

Uses `bpy.ops.mesh.primitive_cube_add` — easy to understand but relies on `bpy.context.active_object` which can break in batch loops.

```python
def create_box(name, min_pt, max_pt, collection_name, material_name):
    x0, y0, z0 = min_pt
    x1, y1, z1 = max_pt
    # CRITICAL: sort coordinates
    x0, x1 = min(x0, x1), max(x0, x1)
    y0, y1 = min(y0, y1), max(y0, y1)
    z0, z1 = min(z0, z1), max(z0, z1)
    cx, cy, cz = (x0+x1)/2, (y0+y1)/2, (z0+z1)/2
    sx = max(x1-x0, 0.001)
    sy = max(y1-y0, 0.001)
    sz = max(z1-z0, 0.001)
    if sx < 0.005 or sy < 0.005 or sz < 0.005:
        return None
    bpy.ops.mesh.primitive_cube_add(size=1, location=(cx, cy, cz), scale=(sx, sy, sz))
    obj = bpy.context.active_object
    obj.name = name
    bpy.ops.object.transform_apply(scale=True)
    mat = bpy.data.materials.get(material_name)
    if mat: obj.data.materials.append(mat)
    col = bpy.data.collections.get(collection_name)
    if col:
        for c in obj.users_collection: c.objects.unlink(obj)
        col.objects.link(obj)
    return obj
```

**Approach B: bmesh (for batch creation, proven June 2026 session 2, 24 objects)**

Uses `bmesh.ops.create_cube` + direct object creation — no `bpy.ops` context dependency, more reliable in loops. Takes `location` (center) and `size` (full dimensions as tuple):

```python
import bmesh
from mathutils import Vector

def add_box(name, loc, size, collection_name, material_name):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    obj.location = loc
    obj.scale = size
    col = get_or_create_collection(collection_name)
    col.objects.link(obj)
    if material_name in bpy.data.materials:
        obj.data.materials.append(bpy.data.materials[material_name])
    return obj
```

Both approaches work. Approach B is preferred for rapid scene builds because it avoids operator context issues.

### Cycles Materials (cliff_house_02 palette)

| Material Tag | Base Color (R,G,B) | Roughness | Metallic | Notes |
|---|---|---|---|---|
| M_Concrete_WarmBone | 0.88, 0.85, 0.80 | 0.65 | 0.0 | Walls, slabs |
| M_Glass_TintedBronze | 0.5, 0.55, 0.6 | 0.02 | 0.0 | Transmission Weight=0.7, IOR=1.52 |
| M_Aluminum_Bronze | 0.65, 0.50, 0.35 | 0.2 | 1.0 | Warm bronze, fully metallic |
| M_Stone_Fieldstone | 0.5, 0.47, 0.42 | 0.8 | 0.0 | Retaining wall |
| M_Terrain_DesertCoastal | 0.5, 0.45, 0.32 | 0.9 | 0.0 | Ground plane |
| M_Concrete_Pool | 0.4, 0.6, 0.7 | 0.3 | 0.0 | Pool basin |
| M_Wood_DarkCedar | 0.4, 0.25, 0.14 | 0.55 | 0.0 | Entry door |
| M_Steel_EdgeTrim | 0.15, 0.15, 0.17 | 0.15 | 1.0 | Railings, garage |

Glass material — TWO APPROACHES, choose by render engine:

**Approach A: Glass BSDF node (simpler, proven June 2026 session 2)**
Use a dedicated `ShaderNodeBsdfGlass` instead of Principled BSDF. This is more reliable for Cycles glass rendering than Principled BSDF with transmission, especially at low sample counts:
```python
nodes = mat.node_tree.nodes
links = mat.node_tree.links
for node in nodes: nodes.remove(node)  # clear defaults
output = nodes.new('ShaderNodeOutputMaterial')
glass = nodes.new('ShaderNodeBsdfGlass')
glass.inputs['Color'].default_value = (0.75, 0.82, 0.85, 1.0)  # slight blue-grey
glass.inputs['Roughness'].default_value = 0.02
glass.inputs['IOR'].default_value = 1.52
links.new(glass.outputs['BSDF'], output.inputs['Surface'])
```

**Approach B: Principled BSDF with Transmission Weight (more control)**
```python
bsdf.inputs["Transmission Weight"].default_value = 0.7  # NOT "Transmission"
bsdf.inputs["IOR"].default_value = 1.52
bsdf.inputs["Specular IOR Level"].default_value = 0.8
```

**PITFALL (June 2026):** Do NOT use `mat.blend_method = 'BLEND'` with `Alpha < 1.0` on Principled BSDF for Cycles glass. This is an EEVEE-only approach — in Cycles it renders the glass panels as opaque flat-colored surfaces with no refraction or transparency. Use Glass BSDF (Approach A) or Transmission Weight (Approach B) instead.

### Blender API Gotchas

- **Sky texture type**: Use `'HOSEK_WILKIE'` (with underscore) — NOT `'HOSEKWILKIE'`, NOT `'NISHITA'`. Valid types: `SINGLE_SCATTERING`, `MULTIPLE_SCATTERING`, `PREETHAM`, `HOSEK_WILKIE`. This enum is case-sensitive.
- **AgX look names**: Must include the `AgX -` prefix. E.g. `'AgX - Medium High Contrast'`, not `'Medium High Contrast'`.
- **Scene compositor**: Access via `bpy.context.scene.use_nodes = True` then the compositor node tree is separate from the scene object. Don't access `scene.node_tree` — that doesn't exist; use the compositor nodes differently.
- **Render timeout**: `bpy.ops.render.render(write_still=True)` blocks synchronously. With GPU (CUDA/OPTIX), 256 samples at 1920×1080 completes in <60s for scenes up to ~5,000 objects. On CPU at 512 samples it may exceed 180s MCP timeout. Use **128 samples at 75% resolution** for test renders, **256 samples at full resolution** for quality renders. Even if MCP times out, the render may still complete and save the file. Always set timeout=600 on the terminal call wrapping a render.
- **Film exposure**: `bpy.context.scene.cycles.film_exposure = 1.2` to brighten.

### Golden Hour Lighting Setup

```python
# Sun light — deep amber, very low angle
sun.data.energy = 8.0
sun.data.color = (1.0, 0.65, 0.3)  # Deep warm amber
sun.rotation_euler = (math.radians(85), 0, math.radians(-50))  # Nearly horizon
sun.data.angle = math.radians(2.0)  # Soft edge

# Hosek/Wilkie sky
sky.turbidity = 8.0  # Dusty golden atmosphere
sky.sun_direction = (-0.9, -0.3, 0.08)  # Nearly setting, W-SW

# Area fill light (sky bounce)
fill.data.energy = 80
fill.data.color = (0.55, 0.6, 0.85)  # Cool blue
fill.data.size = 40  # Very soft
```

### Hero Camera (cliff_house_02)

- Location: (-15, -35, 10) — elevated SW angle, full building in frame
- Target: (5, -5, 4) — center of building mass
- Lens: 28mm (wide, dramatic)
- Use `direction.to_track_quat('-Z', 'Y').to_euler()` for aim
- Previous attempt (-2, -20, 4) was too close — clipped base and right edge

## Saved Artifacts

After Blender setup, save:
- `cliff_house_02_scene.blend` — main Blender working file (301 objects, proven June 2026)
- `cliff_house_02_checkpoint_YYYYMMDD_HHMM.blend` — timestamped backup via `bpy.ops.wm.save_as_mainfile(filepath=..., copy=True)`
- `cliff_house_02_test_render.png` — test render at 128 samples / 75% resolution (~780KB)

Rhino checkpoints (saved before Blender stage):
- `cliff_house_02_site_prep.3dm` — Phase 1 (20 objects)
- `cliff_house_02_massing.3dm` — Phase 2 (31 objects)
- `cliff_house_02_detailing.3dm` — Phase 3 (318 objects)
